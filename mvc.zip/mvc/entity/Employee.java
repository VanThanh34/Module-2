package mvc.entity;

public class Employee  extends Person{

}
