package mvc.service;

public interface Learner {

    void learning();
}
