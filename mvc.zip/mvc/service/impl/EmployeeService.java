package mvc.service.impl;

import mvc.service.Worker;

public class EmployeeService implements Worker {
    @Override
    public void work() {

    }
}
