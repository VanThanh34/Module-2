package mvc.service;

public interface Worker {

    void work();
}
